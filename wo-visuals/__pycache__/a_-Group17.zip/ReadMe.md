Authors:

- Tahir Montgomery
- Chase Tappan

Compile program without visualization using:

```bash
python3 main.py
```

In order to use visualization, first install PyGame

```bash
pip3 install pygame
```

Then run the above command to start program
